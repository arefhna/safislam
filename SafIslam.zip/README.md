# Saf İslam
GitHub-a yükləyin (main branch) → Actions → "Build APK" → Artifacts → SafIslam-apk.
Gradle wrapper lazım deyil: workflow Gradle 8.7 + JDK 17 quraşdırır.
